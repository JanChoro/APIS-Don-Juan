require("dotenv").config();

// guardar el server
const Server = require("./src/server");
// instanciar el server
const server = new Server();

server.listen();