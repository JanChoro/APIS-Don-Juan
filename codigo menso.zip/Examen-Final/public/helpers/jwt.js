const jwt = require("jsonwebtoken");

const genererJWT = ( id,identificacion, nombre, direccion, email, rol ) => {

    const payload = { id,identificacion, nombre, direccion, email, rol }

    return new Promise( (resolve, reject) =>{
        jwt.sign( payload, process.env.CLAVESECRETA, {
            expiresIn: '30m'
        }, (errors,token) =>{
            if (errors) {
                reject("Error al crear el token")
            }
            else{
                resolve(token)
            }
        }
        
        )
    } )

}

module.exports = {
    genererJWT
}