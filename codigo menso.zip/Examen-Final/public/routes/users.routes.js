const { Router } = require("express");

const { getUser,getUserById, postUser, putUser, deleteUser } = require("../controllers/users.controller");
const { validatorPath, emailExisting, idExisting} = require("../middlewares/validations") 
const route = Router();
const { check } = require("express-validator")

route.get("/", getUser);
route.get("/getId/:id", getUserById);

route.post("/", 

[
    check("identificacion").custom(idExisting),
    check("identificacion", "La identificacion debe tener mínimo 7 caracteres y máximo de 10").isLength({min:7,max:10}),
    check("nombre" , "Por favor, ingrese su pvto nombre").not().isEmpty(),
    check("direccion" , "Por favor, ingrese su pvto correo").not().isEmpty(),
    check("email").custom(emailExisting),
    check("contrasena", "La contraseña tiene un mínimo de 6 caracteres").isLength({min:6}),
    check("rol", "Solo se admiten Empleados y Admins").isIn(['Empleado', 'Administrador']),
    validatorPath
] 
,postUser);//Hacer validaciones

route.put("/:id", putUser);

route.delete("/:id", deleteUser);

module.exports = route;