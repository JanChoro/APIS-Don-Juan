const { Router } = require("express");

const { postAuthentication } = require("../controllers/auth.controller")

const route = Router()

route.post("/", postAuthentication);

module.exports = route;