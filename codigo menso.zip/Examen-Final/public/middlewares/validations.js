const { validationResult } = require("express-validator")

const User = require("../models/user.model")

const validatorPath = (req,res,next) =>{

    const errors = validationResult(req);

    if (!errors.isEmpty) {
        res.status(500).json(errors)
    }
    next()

}

const idExisting = async (identificacion = "") =>{

    // hacemos la consulta
    const IdYaExiste = await User.findOne({identificacion}) 
    // camparamos y decidimos
    if (IdYaExiste) {
        throw new Error(`La identificacion ${identificacion} ya existe`)
    }

}

const emailExisting = async (email = "") =>{
    // consultamos
    const emailYaExiste = await User.findOne({email})
    // comparamos
    if (emailYaExiste) {
        throw new Error(`El correo ${email} ya existe`)
    }
}


module.exports = { validatorPath, emailExisting, idExisting } 