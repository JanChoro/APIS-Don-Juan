const User = require("../models/user.model");

const bcryptjs = require("bcryptjs");

// get
const getUser = async (req,res) =>{

    const allUsers = await User.find()
    res.send({
        "ok": 200,
        allUsers
    })

}

// get ID
const getUserById = async (req,res) =>{

    const unSoloUsuario = await User.findById(req.params.id)

    res.send({
        "ok": 200,
        unSoloUsuario
    })

}

// post
const postUser =async (req,res)=> {
// trae los datos
    const { identificacion, nombre, direccion,email, contrasena, rol, estado } = req.body;
    // crea los datos
    const nuevoUsuario = await new User({identificacion, nombre, direccion,email, contrasena, rol, estado})
    // // encriptamos la contraseña
    // const salt = bcryptjs.genSaltSync(10);
    // const User_contrasena = bcryptjs.hashSync(contrasena,salt)

    nuevoUsuario.contrasena = bcryptjs.hashSync(contrasena,10);
    // guarda los datos
    nuevoUsuario.save();

    res.json({
        "ok": 200,
        "msg": "Usuario creado correctamente"
    })
}

const putUser = async (req,res) =>{
    
    // recibimos el parámetro por id
    const paramts = req.params.id; 
    const { identificacion, nombre, direccion,email, contrasena, rol, estado } = req.body;
    // actualizamos
    const actualizarUser = await User.findByIdAndUpdate(paramts, {
        identificacion, nombre, direccion,email, contrasena, rol, estado
    })
    // mensaje
    res.send({
        "ok" : 200,
        "msg" : "Usuario actualizado correctamente :) "
    })
}

const deleteUser = async (req,res) =>{
    // traemos el parámetro id
    const deleteId = req.params.id;
    // eliminamos
    const eliminar = await User.findByIdAndDelete(deleteId)

    res.send({
        "ok" : 200,
        "msg" : "usuario eliminado"
    })
}

//  postUser, putUser, deleteUser
module.exports = {
    getUser,
    getUserById,
    postUser,
    putUser,
    deleteUser
}
