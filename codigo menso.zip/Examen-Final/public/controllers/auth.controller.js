const { request, response } = require("express");

const User = require("../models/user.model"); //Es lo que ya existe

const bcryptjs = require("bcryptjs")

const { genererJWT } = require("../helpers/jwt")


const postAuthentication = async (req = request, res = response) =>{

    // traemos los datos a trabajar 
    const { email, contrasena } = req.body; //Es la peticion 
    try {
        // verificamos que el email exista
        const usuario = await User.findOne({email})
        if (!usuario) {
            res.status(400).json({
                msg: `El usuario ${email} NO existe en la BD`
            })
        }
       
        // verificamos que la contraseña exista
        const compareContraas = bcryptjs.compareSync(contrasena, usuario.contrasena)
        if(!compareContraas){
            res.status(400).json({
                msg: `Acceso denegado, error en la contraseña`
            })
        }

         // verificamos que la el ususario esté activo (estado = true)
         if(!usuario.estado){
            res.status(400).json({
                msg: `El usuario se encuentra inactivo`
            })
        }
        // generamos JWT

        const token = await genererJWT(
            usuario._id,
            usuario.identificacion,
            usuario.nombre,
            usuario.direccion,
            usuario.email,
            usuario.rol
        )
        res.json({
            "ok" : 200,
            token
        })

    } catch (error) {
        console.log("Error del servidor" + error);
        res.status(500).json({
            msg :"Lo sentimos, comunícate con el admin"
        })
        throw new Error("Presentamos falls técnicas :(")

    }
    
}

module.exports = {
    postAuthentication
}