const { Schema, model } = require("mongoose")

const MyModel = new Schema({

    identificacion: {
        type: Number,
        required: ["La identificacion es requerida"]
    },
    nombre: {
        type: String,
        required: ["El nombre es requerido"]
    },
    direccion: {
        type: String,
        required: ["La direccion es requerida"]
    },
    email: {
        type: String,
        required: ["El email es requerida"],
        unique: true
    },
    contrasena: {
        type: String,
        required: ["La contrasena es requerida"]
    },
    rol: {
        type: String,
        required: ["El rol es requerida"]
    },

    estado: {
        type: Boolean,
        default: true
    }


})

module.exports= model("user", MyModel)