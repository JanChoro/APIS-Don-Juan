const mongoose = require("mongoose");

const DBConexion = ()=>{
    try {
        
        mongoose.connect(process.env.MONGO_CNN)
        console.log("Conexion exitosa");

    } catch (error) {
        console.log("Error de conexion " + error);
    }
}

module.exports = {
    DBConexion
}